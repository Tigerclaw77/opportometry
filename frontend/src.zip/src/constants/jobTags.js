export const JOB_TAG_CATEGORIES = [
  {
    label: "Clinical Focus",
    tags: ["Glaucoma", "Pediatrics", "Retina", "Dry Eye", "Low Vision", "Medical Optometry"]
  },
  {
    label: "Schedule",
    tags: ["Full-Time", "Part-Time", "Per Diem", "Flexible", "Evenings", "Weekends"]
  },
  {
    label: "Skills & Languages",
    tags: ["Bilingual", "Spanish", "Tech-Savvy", "Sales-Oriented", "Scribing Experience", "Coding & Billing"]
  },
  {
    label: "Practice Setting",
    tags: ["Private Practice", "Retail", "Hospital-Based", "Mobile", "Academic"]
  },
  {
    label: "Location Type",
    tags: ["Urban", "Suburban", "Rural", "Remote Eligible"]
  }
];
