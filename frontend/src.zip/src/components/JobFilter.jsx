import React, { useState } from "react";
import { MapPin, Navigation } from "lucide-react";
import TagInput from "./TagInput";
import "../styles/JobFilter.css";

const JobFilter = ({ filters, onFilterChange, onClear }) => {
  const [locationInput, setLocationInput] = useState(filters.location || "");
  const [loadingLocation, setLoadingLocation] = useState(false);

  const handleTagAdd = (tag) => {
    if (!filters.searchTags.includes(tag)) {
      onFilterChange({ ...filters, searchTags: [...filters.searchTags, tag] });
    }
  };

  const handleTagRemove = (tagToRemove) => {
    onFilterChange({
      ...filters,
      searchTags: filters.searchTags.filter((tag) => tag !== tagToRemove),
    });
  };

  const toggleLogic = () => {
    onFilterChange({
      ...filters,
      tagLogic: filters.tagLogic === "and" ? "or" : "and",
    });
  };

  const handleUseMyLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation not supported.");
      return;
    }

    setLoadingLocation(true);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        try {
          const res = await fetch(
            `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${process.env.REACT_APP_GOOGLE_MAPS_API_KEY}`
          );
          const data = await res.json();
          const components = data.results[0]?.address_components || [];

          const city = components.find((c) => c.types.includes("locality"))?.long_name || "";
          const state = components.find((c) => c.types.includes("administrative_area_level_1"))?.short_name || "";
          const location = [city, state].filter(Boolean).join(", ");

          setLocationInput(location);
          onFilterChange({ ...filters, location });
        } catch (error) {
          console.error("Location error:", error);
          alert("Failed to fetch location.");
        } finally {
          setLoadingLocation(false);
        }
      },
      (err) => {
        console.error("Geolocation error:", err);
        alert("Failed to retrieve location.");
        setLoadingLocation(false);
      }
    );
  };

  return (
    <div className="job-filter">
      <div className="filter-controls">
        <TagInput
          tags={filters.searchTags}
          onAddTag={handleTagAdd}
          onRemoveTag={handleTagRemove}
        />

        {/* Location input with inline icon */}
        <div className="location-input-wrapper">
          <input
            type="text"
            placeholder="City, State"
            value={locationInput}
            onChange={(e) => {
              setLocationInput(e.target.value);
              onFilterChange({ ...filters, location: e.target.value });
            }}
          />
          <button
            className="location-icon-button"
            onClick={handleUseMyLocation}
            disabled={loadingLocation}
            title="Use my location"
          >
            <Navigation size={16} />
          </button>
        </div>

        <button className="logic-toggle" onClick={toggleLogic}>
          {filters.tagLogic === "and" ? "AND" : "OR"} Logic
        </button>

        <button className="clear-filters" onClick={onClear}>
          Clear Filters
        </button>
      </div>
    </div>
  );
};

export default JobFilter;
