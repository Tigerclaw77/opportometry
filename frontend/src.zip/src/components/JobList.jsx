// FULLY RESTORED JobList.jsx with default optometrist filter, all original code preserved

import React, { useState, useEffect, useRef } from "react";
import { useSelector } from "react-redux";
import { useSearchParams } from "react-router-dom";
import { Star, CheckCircle } from "lucide-react";
import {
  fetchJobs,
  addJobToFavorites,
  applyToJob,
  getUserJobInteractions,
} from "../utils/api";
import JobFilter from "./JobFilter";
import "../styles/JobCard.css";

const GOOGLE_MAPS_API_KEY = process.env.REACT_APP_GOOGLE_MAPS_API_KEY;
const PAGE_SIZE = 10;

const JobList = () => {
  const { _id, user } = useSelector((state) => state.auth);
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [filters, setFilters] = useState({ showFilters: false, searchTags: [], tagLogic: "and" });
  const [favorites, setFavorites] = useState(new Set());
  const [appliedJobs, setAppliedJobs] = useState(new Set());
  const [selectedJob, setSelectedJob] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showMap, setShowMap] = useState(true);
  const [mapReady, setMapReady] = useState(false);
  const [sort, setSort] = useState("newest");

  const [searchParams, setSearchParams] = useSearchParams();
  const page = parseInt(searchParams.get("page") || "1", 10);

  const mapRef = useRef(null);
  const mapInstance = useRef(null);
  const markerCluster = useRef(null);
  const debounceTimeout = useRef(null);

  const DEFAULT_ROLE_TAGS = {
    optometrist: "optometrist",
    technician: "technician",
    assistant: "vision assistant",
    ophthalmologist: "ophthalmologist",
    frontdesk: "front desk",
  };

  useEffect(() => {
    const hasCustomFilters = filters.searchTags.length > 0 || filters.location || filters.type;
    const alreadyStored = localStorage.getItem("defaultRoleFilter");

    if (!hasCustomFilters && !alreadyStored) {
      const defaultTag = "optometrist";
      localStorage.setItem("defaultRoleFilter", defaultTag);
      setFilters((prev) => ({
        ...prev,
        searchTags: [...(prev.searchTags || []), defaultTag],
      }));
    }
  }, [filters]);

  useEffect(() => {
    const initial = Object.fromEntries([...searchParams.entries()]);
    delete initial.page;
    delete initial.sort;
    setFilters({
      showFilters: false,
      ...initial,
      searchTags: initial.searchTags ? initial.searchTags.split(",") : [],
      tagLogic: initial.tagLogic || "and",
    });
    setSort(searchParams.get("sort") || "newest");
  }, [searchParams]);

  useEffect(() => {
    const loadJobs = async () => {
      try {
        const data = await fetchJobs();
        setJobs(data);
        setFilteredJobs(data);
      } catch (error) {
        console.error("Error fetching jobs:", error.message);
      }
    };
    loadJobs();
  }, []);

  useEffect(() => {
    const fetchInteractions = async () => {
      if (!_id) return;
      try {
        const { favorites, appliedJobs } = await getUserJobInteractions();
        setFavorites(new Set(favorites));
        setAppliedJobs(new Set(appliedJobs));
      } catch (error) {
        console.error("Error loading job interactions:", error.message);
      }
    };
    fetchInteractions();
  }, [_id]);

  useEffect(() => {
    clearTimeout(debounceTimeout.current);
    debounceTimeout.current = setTimeout(() => {
      const { location = "", type = "", searchTags = [], tagLogic = "and" } = filters;

      let filtered = jobs.filter((job) => {
        const lowerTitle = job.title.toLowerCase();
        const lowerCompany = job.company.toLowerCase();

        const matchesTags =
          !searchTags.length ||
          (tagLogic === "and"
            ? searchTags.every(
                (tag) => lowerTitle.includes(tag.toLowerCase()) || lowerCompany.includes(tag.toLowerCase())
              )
            : searchTags.some(
                (tag) => lowerTitle.includes(tag.toLowerCase()) || lowerCompany.includes(tag.toLowerCase())
              ));

        const matchesLocation =
          !location || job.location.toLowerCase().includes(location.toLowerCase());

        const matchesType =
          !type || (job.type && job.type.toLowerCase() === type.toLowerCase());

        return matchesTags && matchesLocation && matchesType;
      });

      if (sort === "newest") {
        filtered = filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      } else if (sort === "salary-high") {
        filtered = filtered.sort((a, b) => (b.salary || 0) - (a.salary || 0));
      } else if (sort === "salary-low") {
        filtered = filtered.sort((a, b) => (a.salary || 0) - (b.salary || 0));
      }

      setFilteredJobs(filtered);
      setSearchParams({
        ...filters,
        searchTags: searchTags.join(","),
        tagLogic,
        sort,
        page: "1",
      });
    }, 400);
  }, [filters, jobs, sort, setSearchParams]);

  useEffect(() => {
    if (!showMap || !jobs.length) return;

    const initMap = () => {
      if (!mapRef.current) return;

      mapInstance.current = new window.google.maps.Map(mapRef.current, {
        center: { lat: 30.1659, lng: -95.4613 },
        zoom: 9,
        mapTypeControl: false,
        streetViewControl: false,
      });

      const bounds = new window.google.maps.LatLngBounds();
      const markers = [];

      jobs.forEach((job) => {
        if (job.latitude && job.longitude) {
          const position = { lat: job.latitude, lng: job.longitude };
          bounds.extend(position);

          const marker = new window.google.maps.Marker({
            position,
            map: mapInstance.current,
            title: job.title,
          });

          marker.addListener("click", () => {
            setSelectedJob(job);
            setIsModalOpen(true);
          });

          markers.push(marker);
        }
      });

      if (markers.length > 0) {
        mapInstance.current.fitBounds(bounds);
      }

      if (window.MarkerClusterer && markers.length > 0) {
        markerCluster.current = new window.MarkerClusterer(
          mapInstance.current,
          markers,
          {
            imagePath:
              "https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m",
          }
        );
      }
    };

    if (!window.google?.maps) {
      const existingScript = document.getElementById("googleMaps");
      if (!existingScript) {
        const script = document.createElement("script");
        script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places`;
        script.id = "googleMaps";
        script.async = true;
        script.defer = true;
        script.onload = () => {
          setMapReady(true);
        };
        document.body.appendChild(script);
      }
    } else {
      setMapReady(true);
    }

    if (mapReady) {
      setTimeout(initMap, 0);
    }
  }, [showMap, jobs, mapReady]);

  const paginatedJobs = filteredJobs.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const totalPages = Math.ceil(filteredJobs.length / PAGE_SIZE);

  const handleFavorite = async (jobId) => {
    if (!_id) return;
    try {
      await addJobToFavorites(jobId);
      setFavorites((prev) => {
        const updated = new Set(prev);
        updated.has(jobId) ? updated.delete(jobId) : updated.add(jobId);
        return updated;
      });
    } catch (error) {
      console.error("Error updating favorites:", error.message);
    }
  };

  const handleApply = async (jobId) => {
    if (!_id || appliedJobs.has(jobId)) return;
    try {
      await applyToJob(jobId);
      setAppliedJobs((prev) => new Set(prev).add(jobId));
    } catch (error) {
      console.error("Error applying to job:", error.message);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedJob(null);
  };

  return (
    <div className="job-list">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2>Available Jobs</h2>
        {!user && filters.searchTags.includes("optometrist") && (
          <div style={{ marginTop: "10px", fontSize: "0.9rem", color: "#444" }}>
            Showing optometrist jobs by default. {" "}
            <a href="/login" style={{ color: "#007bff", textDecoration: "underline" }}>
              Log in
            </a>{" "}
            to access full filters.
          </div>
        )}
        <button onClick={() => setShowMap((prev) => !prev)}>
          {showMap ? "Hide Map" : "Show Map"}
        </button>
      </div>

      <JobFilter
        filters={filters}
        onFilterChange={setFilters}
        onClear={() =>
          setFilters({
            showFilters: filters.showFilters,
            searchTags: [],
            tagLogic: "and",
          })
        }
      />

      <div style={{ textAlign: "right", marginBottom: "10px" }}>
        <label>
          Sort by:
          <select value={sort} onChange={(e) => setSort(e.target.value)} style={{ marginLeft: "8px" }}>
            <option value="newest">Newest</option>
            <option value="salary-high">Salary (High to Low)</option>
            <option value="salary-low">Salary (Low to High)</option>
          </select>
        </label>
      </div>

      <div
        ref={mapRef}
        style={{
          display: showMap ? "block" : "none",
          width: "100%",
          height: "300px",
          marginBottom: "20px",
          borderRadius: "10px",
          overflow: "hidden",
        }}
      />

      <div className="job-cards">
        {paginatedJobs.map((job) => (
          <div
            key={job._id}
            className="job-card"
            onClick={() => {
              setSelectedJob(job);
              setIsModalOpen(true);
            }}
          >
            <div className="job-icon-container">
              <Star
                size={18}
                className={favorites.has(job._id) ? "job-icon favorite active" : "job-icon favorite"}
                onClick={(e) => {
                  e.stopPropagation();
                  handleFavorite(job._id);
                }}
              />
              <CheckCircle
                size={18}
                className={appliedJobs.has(job._id) ? "job-icon applied active" : "job-icon applied"}
              />
            </div>
            <h3>{job.title}</h3>
            <p>{job.company}</p>
            <p>{job.location}</p>
          </div>
        ))}
      </div>

      {totalPages > 1 && (
        <div style={{ textAlign: "center", marginTop: "20px" }}>
          {[...Array(totalPages)].map((_, idx) => (
            <button
              key={idx + 1}
              style={{
                padding: "6px 12px",
                margin: "0 5px",
                backgroundColor: idx + 1 === page ? "#005a78" : "#eee",
                color: idx + 1 === page ? "#fff" : "#333",
                border: "none",
                borderRadius: "4px",
                cursor: "pointer",
              }}
              onClick={() =>
                setSearchParams({
                  ...filters,
                  searchTags: (filters.searchTags || []).join(","),
                  tagLogic: filters.tagLogic,
                  sort,
                  page: (idx + 1).toString(),
                })
              }
            >
              {idx + 1}
            </button>
          ))}
        </div>
      )}

      {isModalOpen && selectedJob && (
        <div className="modal-overlay active" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>{selectedJob.title}</h2>
            <p>
              <strong>Company:</strong> {selectedJob.company}
            </p>
            <p>
              <strong>Location:</strong> {selectedJob.location}
            </p>
            <p>
              <strong>Description:</strong> {selectedJob.description}
            </p>
            {selectedJob.salary && (
              <p>
                <strong>Salary:</strong> ${selectedJob.salary}
              </p>
            )}
            <div className="modal-icons">
              <Star
                size={18}
                className={favorites.has(selectedJob._id) ? "job-icon favorite active" : "job-icon favorite"}
                onClick={(e) => {
                  e.stopPropagation();
                  handleFavorite(selectedJob._id);
                }}
              />
              <CheckCircle
                size={18}
                className={appliedJobs.has(selectedJob._id) ? "job-icon applied active" : "job-icon applied"}
              />
            </div>
            <button onClick={closeModal}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobList;
